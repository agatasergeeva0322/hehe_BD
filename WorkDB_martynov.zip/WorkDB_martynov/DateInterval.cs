﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkDB_martynov
{
    public class DateInterval
    {

        public int Months { get; private set; }
        public int Days { get; private set; }

        int[] DaysCount = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

        public DateInterval(DateTime date1, DateTime date2)
        {
            DateTime min, max;

            min = date1 < date2 ? date1 : date2;
            max = date1 > date2 ? date1 : date2;

            if (min.Year == max.Year && min.Month == max.Month)
            {
                Months = 0;
                Days = (max - min).Days;
                return;
            }

            Months = ((max.Year - min.Year) * 12) + max.Month - min.Month;

            if (max.Day < min.Day)
            {
                Months--;
            }

            int PrevDays = DaysCount[max.Month - 2];

            if (max.Month == 2 && max.Year % 4 == 0)
            {
                PrevDays++;
            }

            Days = (PrevDays - min.Day) + max.Day;
        }

    }
}
