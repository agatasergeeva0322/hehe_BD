﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WorkDB_martynov
{
    public partial class Admin_frm : Form
    {

        private List<User> users = new List<User>();
        string connectionString = Authorization_frm.connectionString;

        public void GetFullData()
        {
            string query = "select * from Users";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            users.Clear();
                            while (reader.Read())
                            {
                                User user = new User();
                                user.id = reader.GetInt32(0);
                                user.login = reader.GetString(1);
                                user.password = reader.GetString(2);
                                user.tries = reader.GetInt32(3);
                                user.date = reader.GetDateTime(4);
                                user.active = reader.GetBoolean(5);
                                user.role = reader.GetString(6);
                                users.Add(user);
                            }

                        }
                    }
                }
                catch
                {
                    MessageBox.Show("Ошибка");
                }

            }
        }

        public void RefreshDataGridView()
        {
            dataGridView1.Rows.Clear();
            foreach (User user in users)
            {
                dataGridView1.Rows.Add(user.id, user.login, user.password, user.tries, user.date, user.active, user.role);
            }
        }

        public Admin_frm()
        {
           
            InitializeComponent();
        }

        private void Admin_frm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GetFullData();
            RefreshDataGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (tabControl1.SelectedIndex)
            {
                case 0:
                    if (textBox4.Text != "" && textBox3.Text != "" && (comboBox3.Text == "user" || comboBox3.Text == "admin"))
                    {
                        string command = $"select * from Users where Login = '{textBox4.Text}'";
                        if (Authorization_frm.Command(command) == 0)
                        {
                            DateTime temp = DateTime.UtcNow;
                            Authorization_frm.Register(textBox4.Text, textBox3.Text, 0, temp, 1, comboBox3.Text);
                            GetFullData();
                            RefreshDataGridView();
                            MessageBox.Show("Пользователь успешно добавлен");
                        }
                        else
                        {
                            MessageBox.Show("Такой пользователь уже существует");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Данные введены неверно");
                    }
                    break;

                case 1:
                    if (textBox1.Text != "" && textBox2.Text != "" && (comboBox1.Text == "true" || comboBox1.Text == "false") && (comboBox2.Text == "user" || comboBox2.Text == "admin"))
                    {
                        string command = $"select * from Users where Login = '{textBox1.Text}'";
                        if (Authorization_frm.Command(command) > 0)
                        {
                            DateTime temp = DateTime.UtcNow;

                            string sqlFormattedDate = temp.ToString("yyyy-MM-dd HH:mm:ss.fff");
                            string edit = $"update Users set password = '{textBox2.Text}', Active = '{comboBox1.Text}', Role = '{comboBox2.Text}', Count = '0', Date = '{sqlFormattedDate}' where login = '{textBox1.Text}'";
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                connection.Open();
                                using (SqlCommand query = new SqlCommand(edit, connection))
                                {
                                    query.ExecuteNonQuery();
                                }
                            }
                            GetFullData();
                            RefreshDataGridView();
                            MessageBox.Show("Данные об пользователе успешно обновлены");
                        }
                        else
                        {
                            MessageBox.Show("Такого пользователя не существует");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Данные введены неверно");
                    }

                    break;
                case 2:
                    if (textBox5.Text != "" && textBox6.Text != "")
                    {
                        try
                        {
                            DateTime date1 = Convert.ToDateTime(textBox5.Text);
                            DateTime date2 = Convert.ToDateTime(textBox6.Text);
                            string converteddate1 = date1.ToString("yyyy-MM-dd");
                            string converteddate2 = date2.ToString("yyyy-MM-dd");
                            string query = $"update Users set Active ='0' where Date >= '{converteddate1}' and Date <= '{converteddate2}'";
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                connection.Open();
                                using (SqlCommand command = new SqlCommand(query, connection))
                                {
                                    command.ExecuteNonQuery();
                                }
                            }
                            GetFullData();
                            RefreshDataGridView();
                            MessageBox.Show($"Все пользователи зарегистрированные в период с {converteddate1} по {converteddate2} заблокированы!");
                        }
                        catch
                        {
                            MessageBox.Show("Не удалось определить дату");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Заполните все поля");
                    }
                    break;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = $"update Users set Active = '1' where Active = '0'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
            GetFullData();
            RefreshDataGridView();
            MessageBox.Show("Все пользователи разблокированы");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "select  Id, Login, Password, Count, Date, Active, Role from Users where Active = '0'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        users.Clear();
                        while (reader.Read())
                        {
                            User user = new User();
                            user.id = reader.GetInt32(0);
                            user.login = reader.GetString(1);
                            user.password = reader.GetString(2);
                            user.tries = reader.GetInt32(3);
                            user.date = reader.GetDateTime(4);
                            user.active = reader.GetBoolean(5);
                            user.role = reader.GetString(6);
                            users.Add(user);
                        }
                    }
                }
            }
            RefreshDataGridView();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DateTime today = DateTime.Now;
            string converted = today.ToString("yyyy-MM-dd HH:mm:ss.fff");

            string query = $"select  Id, Login, Password, Count, Date, Active, Role from Users where Date = '{converted}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        users.Clear();
                        while (reader.Read())
                        {
                            User user = new User();
                            user.id = reader.GetInt32(0);
                            user.login = reader.GetString(1);
                            user.password = reader.GetString(2);
                            user.tries = reader.GetInt32(3);
                            user.date = reader.GetDateTime(4);
                            user.active = reader.GetBoolean(5);
                            user.role = reader.GetString(6);
                            users.Add(user);
                        }
                    }
                }
            }
            RefreshDataGridView();
        }

        private void Admin_frm_Load(object sender, EventArgs e)
        {
            GetFullData();
            RefreshDataGridView();
        }
    }
    
}
