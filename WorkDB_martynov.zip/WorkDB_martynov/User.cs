﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkDB_martynov
{
    public class User
    {
        public int id;
        public string login;
        public string password;
        public int tries;
        public DateTime date;
        public bool active;
        public string role;
    }
}
