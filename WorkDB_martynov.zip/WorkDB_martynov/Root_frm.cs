﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkDB_martynov
{
    public partial class Root_frm : Form
    {
        public static string login;
        User user = Authorization_frm.GetDataByLogin(login);
        string connectionString = Authorization_frm.connectionString;

        public Root_frm()
        {
            InitializeComponent();
        }

        private void Root_frm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == user.password)
            {
                if (textBox2.Text != textBox1.Text)
                {
                    if (textBox2.Text == textBox3.Text)
                    {
                        string command = $"update Users set password = '{textBox2.Text}' where login = '{user.login}'";
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();
                            using (SqlCommand query = new SqlCommand(command, connection))
                            {
                                query.ExecuteNonQuery();
                            }
                        }
                        MessageBox.Show("Пароль успешно обновлен");
                    }
                    else
                    {
                        MessageBox.Show("Пароли не совпадают");
                    }
                }
                else
                {
                    MessageBox.Show("Новый пароль не может быть как старый");
                }
            }
            else
            {
                MessageBox.Show("Неверный пароль");
            }
        }

        private void Root_frm_Load(object sender, EventArgs e)
        {
            label1.Text = user.login;
            label2.Text = user.date.ToString();
        }
    }
}
