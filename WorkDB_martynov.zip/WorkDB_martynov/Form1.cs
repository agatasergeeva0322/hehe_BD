﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WorkDB_martynov
{

   
    public partial class Authorization_frm : Form
    {
        public static string connectionString = @"Data Source=PC328-01\SQLEXPRESS;Integrated Security=SSPI;Initial Catalog=SecurityDB_Sergeeva";
        private List<User> users = new List<User>();


        public static int Command(string query)
        {
            int number;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    number = Convert.ToInt32(command.ExecuteScalar());
                }
            }
            return number;
        }

        public static User GetDataByLogin(string login)
        {
            string query = $"select * from User_tbl where Login = '{login}'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            User user = new User();
                            user.id = reader.GetInt32(0);
                            user.login = reader.GetString(1);
                            user.password = reader.GetString(2);
                            user.tries = reader.GetInt32(3);
                            user.date = reader.GetDateTime(4);
                            user.active = reader.GetBoolean(5);
                            user.role = reader.GetString(6);
                            return user;
                        }
                        else
                        {
                            throw new Exception("Логин не был найден");
                        }

                    }
                }
            }
        }

        public void IsInactive(User user)
        {
            DateTime temp = DateTime.UtcNow;
            DateInterval dateInterval = new DateInterval(temp, user.date);
            if (dateInterval.Months >= 1)
            {
                string query = $"update Users set active = '0' where login = '{user.login}'";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand ban = new SqlCommand(query, connection))
                    {
                        ban.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Вы не заходили более месяца, ваш аккаунт заблокирован");
            }

        }

        public void GetData()
        {
            string query = "select * from User_tbl";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            users.Clear();
                            while (reader.Read())
                            {
                                User user = new User();
                                user.id = reader.GetInt32(0);
                                user.login = reader.GetString(1);
                                user.password = reader.GetString(2);
                                user.tries = reader.GetInt32(3);
                                user.date = reader.GetDateTime(4);
                                user.active = reader.GetBoolean(5);
                                user.role = reader.GetString(6);
                                users.Add(user);
                            }
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("ошибка!");
                }

            }
        }
        public static void Register(string login, string password, int tries, DateTime date, int active, string role)
        {
            string query = "insert into Users(Id, Login, Password, Count, Date, Active, Role) Values(@Id, @Login, @Password, @Count, @Date, @Active, @Role)";
            string getid = "select isnull(max(Id),0) + 1 from users";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    int id;

                    using (SqlCommand command = new SqlCommand(getid, connection))
                    {
                        id = (int)command.ExecuteScalar();
                    }

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Id", id);
                        command.Parameters.AddWithValue("@login", login);
                        command.Parameters.AddWithValue("@password", password);
                        command.Parameters.AddWithValue("@count", tries);
                        command.Parameters.AddWithValue("@date", date);
                        command.Parameters.AddWithValue("@active", active);
                        command.Parameters.AddWithValue("@role", role);
                        int r = command.ExecuteNonQuery();
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при работой с БД " + ex.Message);
                }

            }
        }


        public Authorization_frm()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!(textBox1.Text == "" || textBox1.Text == " " || textBox2.Text == "" || textBox2.Text == " " || textBox3.Text == "" || textBox3.Text == " "))
            {

                if (textBox2.Text == textBox3.Text)
                {
                    string query = $"SELECT COUNT(*) FROM dbo.User_tbl WHERE login = '{textBox1.Text}'";
                    SqlConnection connect = new SqlConnection(connectionString);
                    connect.Open();
                    SqlCommand command = new SqlCommand(query, connect);
                    int userCount = (int)command.ExecuteScalar();
                    connect.Close();

                    if (userCount > 0)
                    {
                        MessageBox.Show("Такой логин уже есть");
                    }
                    else
                    {
                        string insertQuery = $"INSERT INTO dbo.User_tbl (login, password, Count, date, active, role) VALUES ('{textBox1.Text}', '{textBox2.Text}', 0, '2024-06-1', 'True', 'User')";
                        connect.Open();
                        SqlCommand insertCommand = new SqlCommand(insertQuery, connect);
                        insertCommand.ExecuteNonQuery();
                        connect.Close();
                    }


                }
                else { MessageBox.Show("Подтверждение пароля не совпадает с новым паролем"); }

            }
            else { MessageBox.Show("Заполните все поля"); }
                
        }

        private void Input_btn_Click(object sender, EventArgs e)                                                                        
        {


            string command;
            
                    if (!(Log_Txt.Text == "") && !(Pass_Txt.Text == ""))
                    {
                        command = $"select * from User_tbl where Login = '{Log_Txt.Text}'";
                        if (Command(command) > 0)
                        {
                            User logined = Authorization_frm.GetDataByLogin(Log_Txt.Text);
                    IsInactive(logined);
                    logined = Authorization_frm.GetDataByLogin(logined.login);
                            if (Command(command + $" and Password = '{Pass_Txt.Text}'") > 0)
                            {
                                if (logined.active == false)
                                {
                                    MessageBox.Show("Вы заблокированы");
                                }
                                else
                                {
                                    if (logined.role == "Admin")
                                    {
                                        Admin_frm adminPage = new Admin_frm();
                                        adminPage.ShowDialog();
                                    }
                                    else
                                    {
                                        
                                        Root_frm userPage = new Root_frm();
                                        userPage.ShowDialog();
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Пароль неверен");
                                string tempquery1 = $"update User_tbl set count += '1' where login = '{logined.login}'";
                                using (SqlConnection connection = new SqlConnection(connectionString))
                                {
                                    connection.Open();
                                    using (SqlCommand addtries = new SqlCommand(tempquery1, connection))
                                    {
                                        addtries.ExecuteNonQuery();
                                    }
                                }
                                logined = Authorization_frm.GetDataByLogin(logined.login);
                                if (logined.tries >= 3)
                                {
                                    MessageBox.Show("Ваше количество попыток закончилось.");
                                    string tempquery2 = $"update User_tbl set active = '0' where login = '{logined.login}'";
                                    using (SqlConnection connection = new SqlConnection(connectionString))
                                    {
                                        connection.Open();
                                        using (SqlCommand ban = new SqlCommand(tempquery2, connection))
                                        {
                                            ban.ExecuteNonQuery();
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show($"У вас осталось {logined.tries}/3 попыток");
                                }

                            }
                        }
                        else
                        {
                            MessageBox.Show("Пользователь не найден");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Длина логина и пароля должна быть не менее 5 символов!");
                    }
                    
                
                    
            


















            string connectionString = @"Data Source=PC328-01\SQLEXPRESS;Integrated Security=SSPI;Initial Catalog=SecurityDB_Sergeeva";
            string login = Log_Txt.Text;
            string password = Pass_Txt.Text;


            int failedAttempts = 0;
            bool isBlocked = false;

            using (SqlConnection connect = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM dbo.User_tbl WHERE Login = @Login AND Password = @Password";
                using (SqlCommand command = new SqlCommand(query, connect))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", password);

                    connect.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        // Проверяем, заблокирован ли пользователь
                        string isBlockedQuery = "SELECT Active FROM User_tbl WHERE Login = @Login";
                        using (SqlCommand isBlockedCommand = new SqlCommand(isBlockedQuery, connect))
                        {
                            isBlockedCommand.Parameters.AddWithValue("@Login", login);
                            reader.Close();
                            object isBlockedResult = isBlockedCommand.ExecuteScalar();
                            if (isBlockedResult != null && isBlockedResult != DBNull.Value)
                            {
                                isBlocked = (bool)isBlockedResult;
                            }
                        }

                        if (!isBlocked)
                        {
                            MessageBox.Show("Ваш аккаунт заблокирован. Обратитесь к администратору для разблокировки.");
                            return;
                        }





                        using (SqlConnection connect2 = new SqlConnection(connectionString))
                        {
                            string query2 = "SELECT * FROM dbo.User_tbl WHERE Login = @Login AND Password = @Password";
                            using (SqlCommand command2 = new SqlCommand(query2, connect2))
                            {


                                connect2.Open();
                                SqlDataReader reader2 = command.ExecuteReader();

                                if (reader2.HasRows)
                                {
                                    SqlDataAdapter roleAdapter2 = new SqlDataAdapter($"SELECT Role FROM User_tbl WHERE Login = '{Log_Txt}' AND Password = '{Pass_Txt}'", connect);
                                    DataTable roleTable = new DataTable();
                                    reader2.Close();
                                    roleAdapter2.Fill(roleTable);

                                    if (roleTable.Rows.Count > 0)
                                    {
                                        string userRole = roleTable.Rows[0]["Role"].ToString();

                                        if (userRole == "User")
                                        {
                                            Root_frm form1 = new Root_frm();
                                            form1.Show();
                                            this.Close();
                                        }
                                        else if (userRole == "Admin")
                                        {
                                            Admin_frm form2 = new Admin_frm();
                                            form2.Show();
                                            this.Close();
                                        }
                                    }



                                    SqlDataAdapter adptr = new SqlDataAdapter("select * from User_tbl", connect2);

                                    DataTable table = new DataTable();
                                    adptr.Fill(table);
                                    dataGridView1.DataSource = table;
                                    connect.Close();*//*
                                }
                                else
                                {
                                    MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста, проверьте ещё раз введенные данные.");
                                }
                            }
                        }





                        {
                            
                            failedAttempts++;
                            if (failedAttempts >= 3)
                            {
                                string blockUserQuery = "UPDATE User_tbl SET Active = 0 WHERE Login = @Login";
                                using (SqlCommand blockUserCommand = new SqlCommand(blockUserQuery, connect))
                                {
                                    blockUserCommand.Parameters.AddWithValue("@Login", login);
                                    blockUserCommand.ExecuteNonQuery();
                                }

                                MessageBox.Show("Вы превысили лимит неудачных попыток входа. Ваш аккаунт заблокирован.");
                            }
                            else
                            {
                                MessageBox.Show($"Неверный логин или пароль. Осталось попыток: {3 - failedAttempts}");
                            }
                        }


                    }

                }
            }






















        }
    }
}
